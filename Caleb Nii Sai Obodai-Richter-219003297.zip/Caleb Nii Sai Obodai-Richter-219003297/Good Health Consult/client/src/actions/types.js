export const GET_ERRORS = "GET_ERRORS";
export const USER_LOADING = "USER_LOADING";
export const SET_CURRENT_USER = "SET_CURRENT_USER";

export const USER_ADD = "USER_ADD";
export const USER_UPDATE = "USER_UPDATE";

export const PATIENT_ADD = "PATIENT_ADD";
export const PATIENT_UPDATE = "PATIENT_UPDATE";
