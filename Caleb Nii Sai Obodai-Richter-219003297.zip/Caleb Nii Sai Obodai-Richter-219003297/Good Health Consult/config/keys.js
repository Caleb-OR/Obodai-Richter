module.exports = {
    mongoURI: "mongodb://mccostic:bestPassw0rd@cluster0-shard-00-00-oh10d.mongodb.net:27017,cluster0-shard-00-01-oh10d.mongodb.net:27017,cluster0-shard-00-02-oh10d.mongodb.net:27017/goodhealthDb?ssl=true&replicaSet=Cluster0-shard-0&authSource=admin&retryWrites=true&w=majority",
    secretOrKey: "FxUum76z"
};