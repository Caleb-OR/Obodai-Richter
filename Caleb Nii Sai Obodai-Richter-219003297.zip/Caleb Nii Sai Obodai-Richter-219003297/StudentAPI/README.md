# RESTful TODO API


### Run

```bash
$ docker-compose up --build
```
